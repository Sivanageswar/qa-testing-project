# QA Testing Project

This repository contains test cases, test reports, and bug reports
for practicing Git push, pull, and collaboration workflows.