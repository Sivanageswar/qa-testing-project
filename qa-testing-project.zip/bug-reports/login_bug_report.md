# Login Bug Report

Bug: Login fails with valid credentials
Severity: High
Status: Open
Steps to Reproduce:
1. Go to login page
2. Enter valid credentials
3. Click Login
Expected Result: User should login successfully
Actual Result: Login failed