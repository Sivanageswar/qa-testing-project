# Login Test Cases

1. Verify login with valid credentials
2. Verify login with invalid password
3. Verify login with empty fields