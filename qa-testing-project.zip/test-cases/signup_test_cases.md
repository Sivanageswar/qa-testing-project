# Signup Test Cases

1. Verify signup with valid details
2. Verify signup with existing email
3. Verify signup with empty fields