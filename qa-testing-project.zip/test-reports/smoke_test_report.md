# Smoke Test Report

## Login Module
- Test 1: Pass
- Test 2: Fail
- Test 3: Pass

## Signup Module
- Test 1: Pass
- Test 2: Pass
- Test 3: Pass